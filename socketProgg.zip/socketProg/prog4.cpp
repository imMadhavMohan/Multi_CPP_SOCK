#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

// msoft: 23.32.253.236; Yahoo: 98.137.11.163;

int main(int argc, const char **argv)
{
	in_addr_t addr;
	struct hostent *hp;
	
	if (argc != 2) {
	    printf("usage: %s IP-address\n", argv[0]);
	    exit (1);
	}

    addr = inet_addr(argv[1]);
	if ((int)addr == -1) {
	    printf("IP-address must be of the form a.b.c.d\n");
	    exit (2);
	}

	hp = gethostbyaddr((char *)&addr, 4, AF_INET);
	if (hp == NULL) {
	    (void) printf("host information for %s not found\n", argv[1]);
	    exit (3);
	}

	for (char **p = hp->h_addr_list; *p != 0; p++) {
	    struct in_addr in;	    
	    memcpy(&in.s_addr, *p, sizeof (in.s_addr));

        printf("%s ----- %s\n", inet_ntoa(in), hp->h_name);
        
	    for (char **q = hp->h_aliases; *q != 0; q++)
	        printf("==> %s", *q);
	    putchar('\n');
	}
	exit (0);
}

