#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>

int main(){
  struct sockaddr_in m_struct;
  struct hostent *host_ent;

  host_ent = gethostbyname("www.google.com"); // www.yahoo.com(202.165.107.49)
  if (host_ent == NULL) { // 
    herror("gethostbyname"); // host_entrror()   
    exit(-1);
  }

  printf("Official name is: %s\n", host_ent->h_name);
  printf("IP address: %s\n", inet_ntoa(*(struct in_addr*)host_ent->h_addr));

  bcopy((char *)host_ent->h_addr, (char *)&m_struct.sin_addr.s_addr, sizeof(host_ent->h_length));
  printf("IP address: %s\n",inet_ntoa(m_struct.sin_addr));

  return 0;  
}