#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>

// twitter: 104.244.42.65; google: 142.251.211.228

int main(){    
    struct hostent *he;
    struct in_addr **addr_list;
    struct in_addr addr;

    // get the addresses of www.yahoo.com:
    he = gethostbyname("www.yahoo.com");
    if (he == NULL) { 
        herror("gethostbyname"); // herror(), 
        exit(1);
    }

    // information of this host:
    printf("Official name is: %s\n", he->h_name);
    printf("IP address: %s\n", inet_ntoa(*(struct in_addr*)he->h_addr));
    
    printf("All addresses: ");
    addr_list = (struct in_addr **)he->h_addr_list;

    for(int i = 0; addr_list[i] != NULL; i++) 
        printf("%s, ", inet_ntoa(*addr_list[i]));

    printf("\n");

    // aliases name
    for (char** q = he->h_aliases; *q != 0; q++)
	    printf("%s, ", *q);    

    putchar('\n');

    return 0;  
}