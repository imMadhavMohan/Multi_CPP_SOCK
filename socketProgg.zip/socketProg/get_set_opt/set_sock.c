#include<stdio.h>
#include<stdlib.h>
#include<errno.h>
#include<string.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netinet/tcp.h>

int main ()
{
        int  a, b, c, d  ;
        if ( ( a = socket ( AF_INET , SOCK_STREAM , 0 ) ) < 0 )
        {
                perror ( " Checking the device : " ) ;
                exit ( 0 ) ;
        }
        d = sizeof ( b ) ;
        if ( getsockopt ( a , IPPROTO_TCP , TCP_MAXSEG , ( char* ) &b , &d ) < 0 )
        {
                perror ( " Error occurred due to the function failure : " ) ;
                exit ( 0 ) ;
        }
        printf ( " \n The probablistic value of b is : = %d " , b ) ;
        c = 12324 ;
        if ( setsockopt ( a , SOL_SOCKET , SO_SNDBUF , ( char* ) &c , sizeof ( c ) ) < 0 )
        {
                perror ( " The chances of failure to respond " ) ;
                exit ( 0 ) ;
        }
        d = sizeof ( c ) ;
        if ( getsockopt ( a , SOL_SOCKET , SO_SNDBUF , ( char* ) &c , &d ) < 0 )
        {
                perror ( " Function does not respond properly : " ) ;
                exit(0);
        }
        printf ( " \nThe  buffer value is = %d \n " , c ) ;
        return 0 ;
}