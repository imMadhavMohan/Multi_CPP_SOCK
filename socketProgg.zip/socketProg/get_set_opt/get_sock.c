#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

int main ( void ) ;

int main ()
{
   int a ;
   int b ;
   socklen_t c = sizeof( b ) ;

   /* Create the functional definition */
   if ( ( a = socket ( AF_INET , SOCK_STREAM , IPPROTO_TCP ) ) < 0 ) {
         perror( " Creating the device : " ) ;
         exit ( EXIT_FAILURE ) ;
      }

   /* Checking the condition of the functional device */
   if ( getsockopt ( a, SOL_SOCKET , SO_KEEPALIVE , &b , &c ) < 0 ){
         perror( " Function may not respond properly : " ) ;
         close ( a ) ;
         exit ( EXIT_FAILURE ) ;
      }
   printf( " The state of the responding function is : %s \n " , ( b ? " ON " : " OFF " ) ) ;

   /* Activate the functional option */
   b = 1 ;
   c = sizeof( b ) ;
   if ( setsockopt ( a, SOL_SOCKET , SO_KEEPALIVE , &b , c ) < 0 ){
         perror( " Detecting some fault " ) ;
         close ( a ) ;
         exit ( EXIT_FAILURE ) ;
      }
   printf( " This functional value is installed  :\n " ) ;

      /* Check the status again */
   if ( getsockopt ( a, SOL_SOCKET , SO_KEEPALIVE , &b , &c ) < 0 ){
         perror( " checking another time : " ) ;
         close ( a ) ;
         exit ( EXIT_FAILURE ) ;
      }
   printf( " Checking the ongoing response : %s \n " , ( b ? " ON " : " OFF " ) ) ;

   close ( a ) ;

      exit ( EXIT_SUCCESS) ;
   return 0 ;
}